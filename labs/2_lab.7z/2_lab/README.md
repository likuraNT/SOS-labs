# MySysLog

Reposytory includes:
 - libmysyslog
 - mysyslogd
 - mysyslog-client


## Repository structure

```
/--
  |-- include/          - all header files
  |
  |-- misc/             - all configurations
  |
  |-- src/              - source code for all packages
  |     |-- drivers/    - drivers (libraries) sources
  |
  |-- .gitignore
  |-- README.md
  |-- Makefile
```

